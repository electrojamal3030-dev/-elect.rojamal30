# Elect.Ronfiga30 SaaS-style landing page

A fully responsive, conversion-oriented landing page built as plain HTML/CSS/JS.

## Included
- Sticky responsive navigation
- Smooth-scroll section anchors
- Bold hero section using the supplied Elect.Ronfiga30 artwork
- Solutions / feature grid
- Pricing tiers
- Testimonial / brand proof section
- Email signup form with front-end success state
- Strong CTAs throughout
- Mobile navigation
- Supplied images in `assets/`

## Run
Open `index.html` in a browser. No build step is required.

The email form is front-end only; connect it to your email provider/API for real subscriptions.
